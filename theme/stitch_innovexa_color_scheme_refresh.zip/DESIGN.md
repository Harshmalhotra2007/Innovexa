---
name: Technical Precision
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#414754'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#727786'
  outline-variant: '#c1c6d7'
  surface-tint: '#0059c5'
  primary: '#0058c3'
  on-primary: '#ffffff'
  primary-container: '#0070f3'
  on-primary-container: '#ffffff'
  inverse-primary: '#aec6ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#555d73'
  on-tertiary: '#ffffff'
  tertiary-container: '#6e758c'
  on-tertiary-container: '#fffeff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#aec6ff'
  on-primary-fixed: '#001a43'
  on-primary-fixed-variant: '#004397'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
  slate-border: '#e2e8f0'
  slate-text-muted: '#94a3b8'
  surface-white: '#ffffff'
typography:
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 24px
  margin-desktop: 48px
  margin-mobile: 16px
---

## Brand & Style
The design system is defined by a **Corporate / Modern** aesthetic that leans into technical sophistication and premium enterprise utility. It targets a professional audience that requires high-density information environments without sacrificing visual polish. 

The visual narrative is one of "engineered elegance"—prioritizing clarity, precision, and structural integrity. By combining a clean, light-mode foundation with the vibrant Intercom Blue, the UI evokes a sense of high-performance reliability. The emotional response is focused and authoritative, positioning the product as a premium tool for complex decision-making.

## Colors
The color strategy employs a "High-Contrast Enterprise" logic. 

- **Primary (#0070f3):** Known as "Intercom Blue," this is the sole driver of action and focus. It is used for primary buttons, active navigation states, and critical progress indicators.
- **Secondary (#64748b):** A professional Slate Gray used for secondary UI elements, icons, and supporting text to provide depth without competing with the primary action.
- **Tertiary (#0f172a):** A deep Midnight Slate used for high-contrast headings and primary text, ensuring maximum legibility.
- **Neutral (#f8fafc):** A crisp, cool-toned slate white used for page backgrounds to distinguish from pure white card surfaces.

## Typography
This design system utilizes **Geist** for its primary typeface, chosen for its Swiss-inspired precision and technical clarity. It provides a clean, neutral voice that excels in data-heavy environments. **JetBrains Mono** is used selectively for labels, code snippets, and tabular data to reinforce the engineered nature of the platform.

Typography scales are disciplined. For headlines, optical kerning is slightly tightened to create a premium, "locked-up" appearance. Body text maintains generous line-heights for sustained readability in technical documentation or long-form data displays.

## Layout & Spacing
The layout follows a **Fixed Grid** model on desktop, centered within a 1280px container to maintain visual control and density. 

- **Desktop (1024px+):** 12-column grid with 24px gutters. Content is organized into modular "panes" that use 24px internal padding.
- **Mobile (Up to 768px):** Transitions to a fluid 4-column grid with 16px margins. 

The spacing rhythm is strictly derived from a 4px base unit. Vertical rhythm is prioritized, using 32px (xl) gaps between major functional blocks to create clear cognitive separation without the need for heavy dividers.

## Elevation & Depth
Depth is conveyed through **Low-Contrast Outlines** and subtle **Tonal Layers**. This system rejects heavy drop shadows in favor of a flatter, more architectural stack.

- **Surface 0 (Background):** `#f8fafc` (Neutral).
- **Surface 1 (Cards/Panels):** Pure white (`#ffffff`) with a 1px border of `#e2e8f0`.
- **Surface 2 (Overlays/Modals):** Pure white with a 1px border and a sharp, minimal shadow (`0 10px 15px -3px rgba(0, 0, 0, 0.05)`) to suggest a slight physical lift from the canvas.

Interactive depth is achieved via color shifts: hover states on secondary elements transition the background to a slightly darker slate tint rather than adding shadow.

## Shapes
The shape language is **Soft (0.25rem)**. This provides a precise, modern appearance that feels professional and calibrated. 

- **Small Components:** Buttons, input fields, and tags use 4px (rounded) corners.
- **Structural Components:** Cards, modals, and sidebars use 8px (rounded-lg) corners to provide a sturdier frame.
- **Circular Elements:** Avatars and status pips remain fully rounded (pill-shaped) to provide a soft counter-point to the otherwise geometric layout.

## Components
- **Buttons:** Primary buttons use `#0070f3` with white text. Secondary buttons use a white background with a `#e2e8f0` border and `#0f172a` text. Ghost buttons use no border and `#64748b` text.
- **Input Fields:** Use 1px `#e2e8f0` borders. Upon focus, the border transitions to `#0070f3` with a 3px ring of `#0070f3` at 10% opacity.
- **Chips:** Small, 4px rounded tags using `label-sm` font. Use `#f1f5f9` backgrounds with `#475569` text for neutral states.
- **Lists:** High-density rows with 12px vertical padding, separated by 1px `#f1f5f9` dividers.
- **Cards:** White surfaces with 1px `#e2e8f0` borders. Headers within cards should be separated by a subtle border or a distinct background tint (`#f8fafc`).
- **Status Indicators:** Use small 8px pips. Colors are functional: Success (Emerald), Warning (Amber), Error (Rose). Always pair with `label-sm` JetBrains Mono text.