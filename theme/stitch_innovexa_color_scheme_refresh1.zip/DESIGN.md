---
name: Lumina Tech Noir
colors:
  surface: '#12131c'
  surface-dim: '#12131c'
  surface-bright: '#383843'
  surface-container-lowest: '#0c0d17'
  surface-container-low: '#1a1b25'
  surface-container: '#1e1f29'
  surface-container-high: '#282934'
  surface-container-highest: '#33343f'
  on-surface: '#e2e1ef'
  on-surface-variant: '#c9c4d8'
  inverse-surface: '#e2e1ef'
  inverse-on-surface: '#2f303a'
  outline: '#938ea1'
  outline-variant: '#484555'
  surface-tint: '#cabeff'
  primary: '#cabeff'
  on-primary: '#32009a'
  primary-container: '#947dff'
  on-primary-container: '#2b0088'
  inverse-primary: '#613de0'
  secondary: '#45dfa4'
  on-secondary: '#003825'
  secondary-container: '#00bd85'
  on-secondary-container: '#00452e'
  tertiary: '#f9bd22'
  on-tertiary: '#402d00'
  tertiary-container: '#b88900'
  on-tertiary-container: '#372700'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e6deff'
  primary-fixed-dim: '#cabeff'
  on-primary-fixed: '#1c0062'
  on-primary-fixed-variant: '#4918c8'
  secondary-fixed: '#68fcbf'
  secondary-fixed-dim: '#45dfa4'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#ffdf9f'
  tertiary-fixed-dim: '#f9bd22'
  on-tertiary-fixed: '#261a00'
  on-tertiary-fixed-variant: '#5c4300'
  background: '#12131c'
  on-background: '#e2e1ef'
  surface-variant: '#33343f'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style
This design system is engineered for high-performance SaaS environments, balancing a deep, atmospheric aesthetic with the precision required for complex data management. The brand personality is sophisticated, technical, and forward-leaning, evoking a sense of "premium engineering."

The visual style utilizes a **Modern Corporate** approach with **Glassmorphic** influences. It avoids the harshness of traditional developer "dark modes" by using deep navy-tinted grays instead of pure black, creating a sense of layered depth. UI elements are defined by subtle inner glows and soft backdrops, ensuring the interface feels refined rather than "gamified."

## Colors
The palette is centered on a "Deep Sea" foundation. 
- **Core Surfaces:** The background uses `#0F0F17` to provide maximum contrast for the primary violet accent, while surfaces use `#191A24` to create a clear visual hierarchy for cards and sidebars.
- **Accents:** The primary Violet (`#7C5CFC`) is used for action-oriented elements and brand highlights.
- **Semantic Logic:** Success (Emerald), Warning (Amber), and Danger (Coral) are calibrated for high legibility against dark backgrounds, using slightly desaturated tones to prevent visual vibration.

## Typography
The system relies on **Inter** for its exceptional legibility in data-dense interfaces. 
- **Headlines:** Use a tighter letter spacing and heavier weights to anchor the page. 
- **Body Text:** Standardizes on a 16px base for optimal readability. 
- **Labels:** Small caps and increased tracking are used for metadata and category headers to provide clear distinction from body content without increasing font size.

## Layout & Spacing
The layout uses a **Fluid Grid** model based on an 8px rhythmic system. 
- **Desktop:** A 12-column grid with 24px gutters. Sidebars are fixed at 280px, while the main content area expands.
- **Tablet:** An 8-column grid with 20px gutters. 
- **Mobile:** A 4-column grid with 16px margins. 
Internal component spacing (padding) should strictly follow the `base` multiples to ensure vertical and horizontal alignment across the dashboard.

## Elevation & Depth
Elevation is communicated through **Tonal Layering** and **Subtle Glows** rather than heavy shadows.
- **Level 0 (Background):** `#0F0F17`.
- **Level 1 (Cards/Sidebar):** `#191A24` with a 1px stroke of `rgba(255,255,255,0.05)`.
- **Level 2 (Modals/Popovers):** `#1E202E` with a 1px stroke of `rgba(255,255,255,0.1)` and a soft Indigo-tinted shadow: `0px 20px 40px rgba(0, 0, 0, 0.4)`.
- **Interactions:** Hover states on interactive surfaces should utilize a very subtle primary-color inner glow to signal focus.

## Shapes
This design system uses a **Rounded** shape language to soften the technical nature of the dark UI. 
- **Standard UI Elements:** Buttons, inputs, and small cards use a `0.5rem` (8px) radius.
- **Large Containers:** Dashboard widgets and main content panels use a `1rem` (16px) radius.
- **Feedback Elements:** Toast notifications and badges use a `rounded-xl` or full pill-shape to distinguish them from structural elements.

## Components
- **Buttons:** Primary buttons use a solid `#7C5CFC` fill with white text. Secondary buttons use a subtle ghost style with a 1px border of `#7C5CFC` and a low-opacity violet background on hover.
- **Input Fields:** Background set to `#0F0F17` (deeper than the surface card) with a 1px border. On focus, the border transitions to the Primary Violet with a 2px outer glow.
- **Chips/Badges:** Small, high-contrast pills. For status indicators (Success/Warning/Danger), use a low-opacity background of the color with a high-saturation text label.
- **Cards:** Use the "Level 1" elevation. Headlines within cards should be `headline-md` and contain secondary text in `body-sm`.
- **Active Navigation:** Sidebar links use a vertical 3px "indicator bar" on the left side in Primary Violet, accompanied by a low-opacity violet background tint across the link row.