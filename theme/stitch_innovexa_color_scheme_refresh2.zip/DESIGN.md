---
name: Kinetic High-Contrast
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#e0c0b1'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#a78b7d'
  outline-variant: '#584237'
  surface-tint: '#ffb690'
  primary: '#ffb690'
  on-primary: '#552100'
  primary-container: '#f97316'
  on-primary-container: '#582200'
  inverse-primary: '#9d4300'
  secondary: '#ffc640'
  on-secondary: '#402d00'
  secondary-container: '#e3aa00'
  on-secondary-container: '#5a4100'
  tertiary: '#c8c6c9'
  on-tertiary: '#303033'
  tertiary-container: '#9b9a9d'
  on-tertiary-container: '#323235'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbca'
  primary-fixed-dim: '#ffb690'
  on-primary-fixed: '#341100'
  on-primary-fixed-variant: '#783200'
  secondary-fixed: '#ffdf9f'
  secondary-fixed-dim: '#f9bd22'
  on-secondary-fixed: '#261a00'
  on-secondary-fixed-variant: '#5c4300'
  tertiary-fixed: '#e4e1e5'
  tertiary-fixed-dim: '#c8c6c9'
  on-tertiary-fixed: '#1b1b1e'
  on-tertiary-fixed-variant: '#47464a'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 64px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Sora
    fontSize: 40px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  button:
    fontFamily: Sora
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  2xl: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style
The design system is engineered for high-impact disruption. It targets a tech-forward audience that values speed, precision, and bold statements. The visual language is rooted in **Modern High-Contrast**, blending deep charcoal surfaces with vibrant, energetic accents to create a sense of focused power.

The emotional response is one of confidence and momentum. By utilizing dark modes with intense saturation in the primary actions, the UI recedes to let critical data and "hero" actions command immediate attention. This is a "loud-functional" aesthetic—aggressive where it matters, but surgically clean in its execution.

## Colors
The palette is built on a foundation of high-density neutrals to maximize the "pop" of functional accents.

- **Primary (#F97316):** Used for critical calls to action, active navigation states, and progress indicators. It represents energy and movement.
- **Secondary (#FBBF24):** Reserved for badges, warnings, and highlighting specific "new" or "alert" status items.
- **Surface & Background:** The background remains at `#121212` to provide a bottomless depth. Interactive surfaces and containers use `#27272A` to create clear object definition without relying on heavy borders.
- **Typography:** Contrast is strictly maintained. Primary text is `#FAFAFA` for maximum readability, while metadata and secondary labels use `#A1A1AA` to establish clear visual hierarchy.

## Typography
The typography strategy pairs geometric boldness with technical precision.

1.  **Headlines (Sora):** A geometric sans-serif with a futuristic edge. Use Bold (700) or ExtraBold (800) for displays to anchor the page.
2.  **Body (Hanken Grotesk):** A modern, highly legible grotesque that maintains a professional tone in long-form content.
3.  **Technical Labels (JetBrains Mono):** Used for small badges, code snippets, or secondary data points to reinforce the "tech disruptive" nature of the product.

All headings should use tight letter-spacing to feel more "industrial" and compact.

## Layout & Spacing
The layout follows a **Fluid Grid** model with aggressive padding to prevent the dark interface from feeling cramped.

- **Desktop:** 12-column grid with 24px gutters. Content is often centered in a max-width container (1280px) to maintain focus.
- **Mobile:** 4-column grid with 16px margins.
- **Rhythm:** Spacing should follow a strict 4px base unit. Use larger gaps (40px+) between major sections to emphasize the minimalist high-contrast style.
- **Alignment:** Components should be edge-aligned to the grid to maintain a "structured" and reliable feel.

## Elevation & Depth
In this design system, depth is achieved through **Tonal Layers** rather than traditional shadows.

- **Level 0 (Background):** `#121212` - The base canvas.
- **Level 1 (Cards/Surfaces):** `#27272A` - Used for primary content containers. No shadow is needed; the color contrast provides the separation.
- **Level 2 (Popovers/Modals):** A slightly lighter gray (`#3F3F46`) with a sharp, high-opacity black shadow (e.g., `0 8px 0 0 #000000`) to create a "brutalist" stacked effect.
- **Interactive States:** Use thin 1px borders of the primary accent color (`#F97316`) for hovered or focused elements to create an "electrical" glow effect.

## Shapes
The shape language is **Soft/Technical**. We avoid perfectly round circles (except for avatars) and sharp 0px corners which can feel dated or overly hostile.

- **Primary Radius:** 0.25rem (4px) for most components (inputs, buttons, small cards).
- **Large Components:** 0.5rem (8px) for main containers and modals.
- **Logic:** This subtle rounding keeps the interface feeling "modern" and "engineered" rather than "organic."

## Components
- **Buttons:**
    - **Primary:** Background `#F97316`, Text `#FAFAFA`. On hover, the background should shift slightly brighter.
    - **Ghost:** Border 1px `#27272A`, Text `#FAFAFA`. On hover, border becomes `#F97316`.
- **Inputs:** Background `#121212`, Border 1px `#3F3F46`, Placeholder Text `#A1A1AA`. Active state uses a 1px `#F97316` border.
- **Cards:** Background `#27272A`. Content within cards should have a 24px internal padding.
- **Badges:** Use `label-sm` typography. Status badges should use `#FBBF24` (Warning) or `#F97316` (New/Info) with a low-opacity background tint of the same color.
- **Navigation:** Use high-contrast states. The active menu item should use a vertical 2px bar of `#F97316` to the left of the label.
- **Selection Controls:** Checkboxes and Radials should use the Primary Orange for the "checked" state, ensuring it vibrates against the dark background.